﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mertekegysegk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //hosszúság
            if (comboBox1.Text != "" && comboBox2.Text != "" && comboBox3.Text != "" && textBox2.Text != "")
            {
                if (comboBox2.SelectedItem == "km" && comboBox3.SelectedItem == "m")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "m" && comboBox3.SelectedItem == "km")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "km" && comboBox3.SelectedItem == "cm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100000);
                }
                if (comboBox2.SelectedItem == "cm" && comboBox3.SelectedItem == "km")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00001);
                }
                if (comboBox2.SelectedItem == "km" && comboBox3.SelectedItem == "dm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10000);
                }
                if (comboBox2.SelectedItem == "dm" && comboBox3.SelectedItem == "km")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .0001);
                }
                if (comboBox2.SelectedItem == "km" && comboBox3.SelectedItem == "mm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000);
                }
                if (comboBox2.SelectedItem == "mm" && comboBox3.SelectedItem == "km")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .000001);
                }
                if (comboBox2.SelectedItem == "m" && comboBox3.SelectedItem == "dm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "dm" && comboBox3.SelectedItem == "m")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                if (comboBox2.SelectedItem == "m" && comboBox3.SelectedItem == "cm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "cm" && comboBox3.SelectedItem == "m")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "m" && comboBox3.SelectedItem == "mm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "mm" && comboBox3.SelectedItem == "m")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "dm" && comboBox3.SelectedItem == "cm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "cm" && comboBox3.SelectedItem == "dm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                if (comboBox2.SelectedItem == "dm" && comboBox3.SelectedItem == "mm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "mm" && comboBox3.SelectedItem == "dm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "cm" && comboBox3.SelectedItem == "mm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "mm" && comboBox3.SelectedItem == "cm")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                //hosszúság
                //tömeg
                if (comboBox2.SelectedItem == "t" && comboBox3.SelectedItem == "kg")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "kg" && comboBox3.SelectedItem == "t")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "t" && comboBox3.SelectedItem == "dkg")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100000);
                }
                if (comboBox2.SelectedItem == "dkg" && comboBox3.SelectedItem == "t")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00001);
                }
                if (comboBox2.SelectedItem == "t" && comboBox3.SelectedItem == "g")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10000000);
                }
                if (comboBox2.SelectedItem == "g" && comboBox3.SelectedItem == "t")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .000001);
                }
                if (comboBox2.SelectedItem == "kg" && comboBox3.SelectedItem == "dk")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "dkg" && comboBox3.SelectedItem == "kg")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "kg" && comboBox3.SelectedItem == "g")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10000);
                }
                if (comboBox2.SelectedItem == "g" && comboBox3.SelectedItem == "kg")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .0001);
                }
                if (comboBox2.SelectedItem == "dkg" && comboBox3.SelectedItem == "g")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "g" && comboBox3.SelectedItem == "dkg")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                //tömeg
                //űrmérték
                if (comboBox2.SelectedItem == "hl" && comboBox3.SelectedItem == "l")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "l" && comboBox3.SelectedItem == "hl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "hl" && comboBox3.SelectedItem == "dl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "dl" && comboBox3.SelectedItem == "hl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "hl" && comboBox3.SelectedItem == "cl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10000);
                }
                if (comboBox2.SelectedItem == "cl" && comboBox3.SelectedItem == "hl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .0001);
                }
                if (comboBox2.SelectedItem == "hl" && comboBox3.SelectedItem == "ml")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100000);
                }
                if (comboBox2.SelectedItem == "ml" && comboBox3.SelectedItem == "hl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00001);
                }
                if (comboBox2.SelectedItem == "l" && comboBox3.SelectedItem == "dl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "dl" && comboBox3.SelectedItem == "l")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                if (comboBox2.SelectedItem == "l" && comboBox3.SelectedItem == "cl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "cl" && comboBox3.SelectedItem == "l")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "l" && comboBox3.SelectedItem == "ml")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "ml" && comboBox3.SelectedItem == "l")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "dl" && comboBox3.SelectedItem == "cl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "cl" && comboBox3.SelectedItem == "dl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                if (comboBox2.SelectedItem == "dl" && comboBox3.SelectedItem == "ml")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "ml" && comboBox3.SelectedItem == "dl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "cl" && comboBox3.SelectedItem == "ml")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10);
                }
                if (comboBox2.SelectedItem == "ml" && comboBox3.SelectedItem == "cl")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .1);
                }
                //űrmérték
                //Terület
                if (comboBox2.SelectedItem == "km²" && comboBox3.SelectedItem == "m²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000);
                }
                if (comboBox2.SelectedItem == "m²" && comboBox3.SelectedItem == "km²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .000001);
                }
                if (comboBox2.SelectedItem == "km²" && comboBox3.SelectedItem == "dm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000000);
                }
                if (comboBox2.SelectedItem == "dm²" && comboBox3.SelectedItem == "km²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .000000001);
                }
                if (comboBox2.SelectedItem == "km²" && comboBox3.SelectedItem == "cm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000000000);
                }
                if (comboBox2.SelectedItem == "cm²" && comboBox3.SelectedItem == "km²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00000000001);
                }
                if (comboBox2.SelectedItem == "km²" && comboBox3.SelectedItem == "mm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000000000000);
                }
                if (comboBox2.SelectedItem == "mm²" && comboBox3.SelectedItem == "cl²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .000000000000001);
                }
                if (comboBox2.SelectedItem == "m²" && comboBox3.SelectedItem == "dm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "dm²" && comboBox3.SelectedItem == "m²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "m²" && comboBox3.SelectedItem == "cm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10000);
                }
                if (comboBox2.SelectedItem == "cm²" && comboBox3.SelectedItem == "m²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .0001);
                }
                if (comboBox2.SelectedItem == "m²" && comboBox3.SelectedItem == "mm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000000);
                }
                if (comboBox2.SelectedItem == "mm²" && comboBox3.SelectedItem == "m²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00000001);
                }
                if (comboBox2.SelectedItem == "dm²" && comboBox3.SelectedItem == "cm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "cm²" && comboBox3.SelectedItem == "dm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                if (comboBox2.SelectedItem == "dm²" && comboBox3.SelectedItem == "mm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 10000);
                }
                if (comboBox2.SelectedItem == "mm²" && comboBox3.SelectedItem == "dm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .0001);
                }
                if (comboBox2.SelectedItem == "cm²" && comboBox3.SelectedItem == "mm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 100);
                }
                if (comboBox2.SelectedItem == "mm²" && comboBox3.SelectedItem == "cm²")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .01);
                }
                //terület
                //térfogat
                if (comboBox2.SelectedItem == "m³" && comboBox3.SelectedItem == "dm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "dm³" && comboBox3.SelectedItem == "m³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "m³" && comboBox3.SelectedItem == "cm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000);
                }
                if (comboBox2.SelectedItem == "cm³" && comboBox3.SelectedItem == "m³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00001);
                }
                if (comboBox2.SelectedItem == "m³" && comboBox3.SelectedItem == "mm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000000);
                }
                if (comboBox2.SelectedItem == "mm³" && comboBox3.SelectedItem == "m³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00000001);
                }
                if (comboBox2.SelectedItem == "dm³" && comboBox3.SelectedItem == "cm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "cm³" && comboBox3.SelectedItem == "dm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                if (comboBox2.SelectedItem == "dm³" && comboBox3.SelectedItem == "mm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000000);
                }
                if (comboBox2.SelectedItem == "mm³" && comboBox3.SelectedItem == "dm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .00001);
                }
                if (comboBox2.SelectedItem == "cm³" && comboBox3.SelectedItem == "mm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1000);
                }
                if (comboBox2.SelectedItem == "mm³" && comboBox3.SelectedItem == "cm³")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * .001);
                }
                //térfogat
                //idő
                if (comboBox2.SelectedItem == "nap" && comboBox3.SelectedItem == "óra")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 24);
                }
                if (comboBox2.SelectedItem == "óra" && comboBox3.SelectedItem == "nap")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) / 24);
                }
                if (comboBox2.SelectedItem == "nap" && comboBox3.SelectedItem == "perc")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 1440);
                }
                if (comboBox2.SelectedItem == "perc" && comboBox3.SelectedItem == "nap")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) / 1440);
                }
                if (comboBox2.SelectedItem == "nap" && comboBox3.SelectedItem == "másodperc")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 86400);
                }
                if (comboBox2.SelectedItem == "másodperc" && comboBox3.SelectedItem == "nap")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) / 86400);
                }
                if (comboBox2.SelectedItem == "óra" && comboBox3.SelectedItem == "perc")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 60);
                }
                if (comboBox2.SelectedItem == "perc" && comboBox3.SelectedItem == "óra")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) / 60);
                }
                if (comboBox2.SelectedItem == "óra" && comboBox3.SelectedItem == "másodperc")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 3600);
                }
                if (comboBox2.SelectedItem == "másodperc" && comboBox3.SelectedItem == "óra")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) / 3600);
                }
                if (comboBox2.SelectedItem == "perc" && comboBox3.SelectedItem == "másodperc")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) * 60);
                }
                if (comboBox2.SelectedItem == "másodperc" && comboBox3.SelectedItem == "perc")
                {
                    textBox1.Text = Convert.ToString(Convert.ToDouble(textBox2.Text) / 60);
                }
            }
            else if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox3.Text == "" || textBox2.Text == "") 
            {
                MessageBox.Show("Töltse ki az összes mezőt!");
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        { 
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Hosszmérték")
            {
                comboBox2.Items.Add("mm");
                comboBox2.Items.Add("cm");
                comboBox2.Items.Add("dm");
                comboBox2.Items.Add("m");
                comboBox2.Items.Add("km");

                comboBox3.Items.Add("mm");
                comboBox3.Items.Add("cm");
                comboBox3.Items.Add("dm");
                comboBox3.Items.Add("m");
                comboBox3.Items.Add("km");
            }
            else if (comboBox1.SelectedItem == "Súlymérték")
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.Add("g");
                comboBox2.Items.Add("dkg");
                comboBox2.Items.Add("kg");
                comboBox2.Items.Add("t");


                comboBox3.Items.Add("g");
                comboBox3.Items.Add("dkg");
                comboBox3.Items.Add("kg");
                comboBox3.Items.Add("t");

            }
            else if (comboBox1.SelectedItem == "Űrmérték")
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.Add("ml");
                comboBox2.Items.Add("cl");
                comboBox2.Items.Add("dl");
                comboBox2.Items.Add("l");
                comboBox2.Items.Add("hl");

                comboBox3.Items.Add("ml");
                comboBox3.Items.Add("cl");
                comboBox3.Items.Add("dl");
                comboBox3.Items.Add("l");
                comboBox3.Items.Add("hl");
            }
            else if (comboBox1.SelectedItem == "Terület")
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.Add("mm²");
                comboBox2.Items.Add("cm²");
                comboBox2.Items.Add("dm²");
                comboBox2.Items.Add("m²");
                comboBox2.Items.Add("km²");

                comboBox3.Items.Add("mm²");
                comboBox3.Items.Add("cm²");
                comboBox3.Items.Add("dm²");
                comboBox3.Items.Add("m²");
                comboBox3.Items.Add("km²");
            }
            else if (comboBox1.SelectedItem == "Térfogat")
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.Add("mm³");
                comboBox2.Items.Add("cm³");
                comboBox2.Items.Add("dm³");
                comboBox2.Items.Add("m³");
              
                comboBox3.Items.Add("mm³");
                comboBox3.Items.Add("cm³");
                comboBox3.Items.Add("dm³");
                comboBox3.Items.Add("m³");
               
            }
            else if (comboBox1.SelectedItem == "Idő")
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.Add("másodpercs");
                comboBox2.Items.Add("perc");
                comboBox2.Items.Add("óra");
                comboBox2.Items.Add("nap");

                comboBox3.Items.Add("másodperc");
                comboBox3.Items.Add("perc");
                comboBox3.Items.Add("óra");
                comboBox3.Items.Add("nap");

            }
        }
    }
}
