﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace penzvaltó
{
    struct adatok {
        public string valuta;
        public int egyseg;
        public double ertek;
                    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {

            //double i = Convert.ToDouble(amount_txt.Text);
            //if (fromcombo1.SelectedItem == "Rubel" && tocombo2.SelectedItem == "Dollar")
            //{
            //    double conver = double.Parse(amount_txt.Text) * 0.015;

            //    display_txt.Text = "Összeg: "+ conver;
            //}
            //if (fromcombo1.SelectedItem == "Rubel" && tocombo2.SelectedItem == "Euro")
            //{
            //    double conver = double.Parse(amount_txt.Text) * 0.014;

            //    display_txt.Text = "Összeg: " + conver;
            //}
            //if (fromcombo1.SelectedItem == "Rubel" && tocombo2.SelectedItem == "Forint")
            //{
            //    double conver = Math.Round((double.Parse(amount_txt.Text) * 5.42),2);

            //    display_txt.Text = "Összeg: " + conver;
            //}
            //if (fromcombo1.SelectedItem == "Dollar" && tocombo2.SelectedItem == "Rubel")
            //{
            //    double conver =Math.Round((double.Parse(amount_txt.Text) * 67.79),2);
            //     display_txt.Text = "Összeg: " + conver;

            //}
            List<adatok> lista = new List<adatok>();
            StreamReader olvas = new StreamReader("valuta.txt");
            string sor = olvas.ReadLine();
            while (!olvas.EndOfStream)
            {
                sor = olvas.ReadLine();
                string[] st = sor.Split(";");
                adatok pufi = new adatok();
                pufi.valuta= st[0];
                pufi.egyseg = int.Parse(st[1]);
                pufi.ertek = Convert.ToDouble(st[2]);
                lista.Add(pufi);
            }olvas.Close();
            double szam1=0;
            double szam2=0;
            int alma = 0;
            double osszeg = 0;
            double bekert = Convert.ToDouble(amount_txt.Text);
            for (int i = 0; i < lista.Count; i++)
            {
                if (fromcombo1.Text != "" && tocombo2.Text != "" && amount_txt.Text != "")
                {
                    if (fromcombo1.Text == lista[i].valuta)
                    {
                        szam1 = lista[i].ertek;
                        alma = lista[i].egyseg;
                    }
                    if (tocombo2.Text == lista[i].valuta)
                    {
                        szam2 = lista[i].ertek;

                    }
                    if (alma == 1)
                    {
                        if (fromcombo1.Text == "HUF")
                        {

                            osszeg = Math.Round(((alma * bekert * 1) / szam2), 2);
                        }
                        else if (tocombo2.Text == "HUF")
                        {
                            osszeg = Math.Round(((alma * bekert * szam1) / 1), 2);
                        }
                        else if (tocombo2.Text == "JPY" || tocombo2.Text == "KRW" || tocombo2.Text == "IDR")
                        {
                            double alap = szam2 / 100;
                            osszeg = Math.Round(((alma * bekert * szam1) / alap), 2);
                        }
                        else
                        {
                            osszeg = Math.Round(((alma * bekert * szam1) / szam2), 2);
                        }
                        // (egységszer * bekért szám *erről valuta értéke) / erre valuta értéke
                    }
                    else if (alma != 1)
                    {
                        double masodik = szam1 / 100;
                        double egyseg = alma / 100;

                        if (tocombo2.Text == "HUF")
                        {
                            osszeg = Math.Round((((egyseg * bekert) * masodik) / 1), 2);
                        }
                        else if (tocombo2.Text == "JPY" || tocombo2.Text == "KRW" || tocombo2.Text == "IDR")
                        {
                            osszeg = Math.Round((((egyseg * bekert) * masodik) / (szam2 / 100)), 2);
                        }
                        else
                        {
                            osszeg = Math.Round((((egyseg * bekert) * masodik) / szam2), 2);
                        }                     
                    }
                }
                else if (fromcombo1.Text == "")
                {
                    MessageBox.Show("Töltse ki a mezőt: Erről a valutáról ");
                }
                else if (tocombo2.Text == "")
                {
                    MessageBox.Show("Töltse ki a mezőt: Erre a valutáról ");
                }
                else if (amount_txt.Text == "")
                {
                    MessageBox.Show("Töltse ki a mezőt: Az érték mezőt ");
                }
            }
            display_txt.Text = "Összeg: " + osszeg;
        }

        private void fromcombo1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
